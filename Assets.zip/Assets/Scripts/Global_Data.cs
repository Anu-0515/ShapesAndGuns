using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Global_Data : MonoBehaviour
{
    private static GameObject instance;

    public int choice;
    public int total_coins;

    public GameObject player;

    void Awake()
    {
        
    }

    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(this.gameObject);
        if (instance == null)
            instance = this.gameObject;
        else
            Destroy(this.gameObject);
        

    }

    // Update is called once per frame
    void Update()
    {
        /*if(player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player");
        }
        else if(player != null)
        {
            total_coins = player.GetComponent<CoinCounter>().coin_score;
        }*/
    }
}
