﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAIMelee : MonoBehaviour
{
    public float speed;
    public Transform target;
    public float dash_force = 20f; 
    public float cooldown = 2f;
    public float min_dist;



    private float angle;
    private Vector3 lookDir;
    private bool IsDashing = false;
    private Rigidbody2D player;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        lookDir = target.position - transform.position;
        angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
        if (lookDir.magnitude >= min_dist)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        }
        else if(IsDashing == false && lookDir.magnitude < min_dist && Time.time > cooldown)
        {
            StartCoroutine(DashAttack());
            cooldown = Time.time + 2f;
            IsDashing = false;
        }
    }

    IEnumerator DashAttack()
    {
        IsDashing = true;
        yield return new WaitForSeconds(0.5f);
        target.transform.position = Vector3.Lerp(target.transform.position, target.transform.position + (lookDir*0.75f), 0.5f) ;
        transform.position += lookDir * 2.5f;
    }

}
