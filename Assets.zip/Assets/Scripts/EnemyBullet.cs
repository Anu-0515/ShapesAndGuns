﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public float Lifetime = 5f;

    void Start()
    {
        StartCoroutine(BulletLifetime());
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "Wall" || collision.gameObject.tag == "bullet")
        {
            Destroy(gameObject);
        }
    }

    IEnumerator BulletLifetime()
    {
        yield return new WaitForSeconds(Lifetime);
        Destroy(gameObject);
    }
}
