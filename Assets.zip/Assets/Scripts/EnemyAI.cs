﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public float speed;
    public Transform target;
    private Vector3 lookDir;
    public float angle;
    public GameObject enemy_bullet;
    public Transform muzzle;
    public float bulletForce = 20f;
    public float cooldown = 1f;
    public float longrangecool = 1.5f;
    public int randomizer;

    public Vector3 offset;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        randomizer = Random.Range(50, 175);
        longrangecool = randomizer * 0.01f;
    }

    // Update is called once per frame
    void Update()
    {
        
        //Gets look direction
        lookDir = target.position - transform.position;
        angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
        
        if (lookDir.magnitude >= 10)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
            if (Time.time > longrangecool)
            {
                GameObject mybullet = Instantiate(enemy_bullet, muzzle.position, muzzle.rotation * Quaternion.Euler(0, 0, Random.Range(-15, 15)));
                Rigidbody2D rb = mybullet.GetComponent<Rigidbody2D>();
                rb.AddForce(mybullet.transform.up * bulletForce, ForceMode2D.Impulse);
                longrangecool = Time.time + (randomizer * 0.01f);
            }
        }
        else if (lookDir.magnitude < 10 && Time.time > cooldown) 
        {
            GameObject mybullet = Instantiate(enemy_bullet, muzzle.position, muzzle.rotation);
            Rigidbody2D rb = mybullet.GetComponent<Rigidbody2D>();
            rb.AddForce(muzzle.up * bulletForce, ForceMode2D.Impulse);
            cooldown = Time.time + 1f;
        }
       

    }

    
}
