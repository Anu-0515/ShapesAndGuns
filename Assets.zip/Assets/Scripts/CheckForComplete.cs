using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckForComplete : MonoBehaviour
{
    public List<GameObject> RoomList = new List<GameObject>();

    public bool StageComplete = false;
    public GameObject WinScreen;
    
    public void AddRoom(GameObject Room)
    {
        RoomList.Add(Room);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
       foreach (GameObject room in RoomList)
        {
            if(room.transform.GetChild(0).GetComponent<EndFight>().IsRoomClear == true)
            {
                StageComplete = true;
            }
            else
            {
                StageComplete = false;
            }
        }

       if(StageComplete == true)
        {
            Debug.Log("Doooonnneeee");
            WinScreen.SetActive(true);
        }
    }
}
