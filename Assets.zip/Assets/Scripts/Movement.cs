﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float moveSpeed = 5f;

    public Rigidbody2D rb;
    public GameObject player;
    public Camera cam;
    public Camera mapcam;
    public float lerp_speed;

    Vector2 movement;
    Vector2 mousePos;

    public Joystick Threshold;
    public Joystick shootJoystick;

    // Update is called once per frame

    void FixedUpdate()
    {
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");
        mousePos = cam.ScreenToWorldPoint(Input.mousePosition);
        cam.transform.position = Vector3.Lerp(cam.transform.position, player.transform.position + new Vector3(0f, 0f, -10f), lerp_speed);
        mapcam.transform.position = Vector3.Lerp(mapcam.transform.position, player.transform.position + new Vector3(0f, 0f, -10f), lerp_speed);

        if (Threshold.InputDir != Vector3.zero)
        {
            movement = Threshold.InputDir;
        }
        rb.MovePosition(rb.position + movement * moveSpeed * Time.deltaTime);

        

        Vector2 lookDir = mousePos - rb.position;
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
        if(shootJoystick.InputDir != Vector3.zero)
        {
           angle = Mathf.Atan2(shootJoystick.InputDir.y, shootJoystick.InputDir.x) * Mathf.Rad2Deg - 90f;
           rb.rotation = angle;
        }

    }
}
