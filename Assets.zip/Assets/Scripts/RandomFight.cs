using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomFight : MonoBehaviour
{
    public GameObject RoomWall;
    public GameObject RoomWall2;
    public Collider2D Trigger;
    public float spawn_posx;
    public float spawn_posy;
    public GameObject[] enemies;
    public GameObject spawner;

    public bool IsRoomClear = false;

    public int enemy_count;

    private Vector3 spawn_point;

    // Start is called before the first frame update
    void Start()
    {
        enemy_count = Random.Range(5, 16);
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            RoomWall.SetActive(true);
            if (RoomWall2 != null)
            {
                RoomWall2.SetActive(true);
            }
            StartCoroutine(Fight());
            Trigger.enabled = false;

        }

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
    }

    IEnumerator Fight()
    {
        yield return new WaitForSeconds(1);
        for(int i=1; i<enemy_count; i++)
        {
            spawn_posx = Random.Range(-45f, 45f);
            spawn_posy = Random.Range(-45f, 45f);
            spawn_point = spawner.transform.position + new Vector3(spawn_posx, spawn_posy, 0f);
            Instantiate(enemies[Random.Range(0,2)], spawn_point, Quaternion.identity);
        }
    }

    IEnumerator EndFight()
    {
        yield return new WaitForSeconds(0.01f);
        Destroy(RoomWall);
        if (RoomWall2 != null)
        {
            Destroy(RoomWall2);
        }
        Destroy(this.gameObject);
    }
}
