﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject Enemy;
    public float timeinterval;
    public float timer = 0;
    public Vector3 jitter;

    // Start is called before the first frame update
    void Start()
    {
        timer = timeinterval;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            timer = timeinterval;
            Instantiate(Enemy, transform.position, transform.rotation);
        }
    }
}
