using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flamethrower : MonoBehaviour
{
    public Joystick shootJoystick;
    public float AOE_radius;
    public bool canshoot = false;

    void Awake()
    {
        shootJoystick = FindObjectOfType(typeof(Joystick)) as Joystick;
    }
    // Start is called before the first frame update
    /*void OnTriggerStay2D(Collider2D other)
    {
        if (other.tag == "Enemy" && shootJoystick.shoot == true)
        {
            other.GetComponent<Kill>().health -= 1f;
            Debug.Log("Whyyyy");
        }
    }*/

    void Update()
    {
        if (shootJoystick.shoot == true)
        {
            canshoot = true;
            Debug.Log("wHHHYYY");
        }
        else
        {
            canshoot = false;
        }
            
        if (canshoot && Input.GetButton("Fire1"))
        {
            Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, AOE_radius);
            foreach (var collider in colliders)
            {
                Debug.Log(collider.gameObject.name);
                if(collider.gameObject.tag == "Enemy")
                {
                    collider.GetComponent<Kill>().health -= 1f;
                }
                
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, AOE_radius);
    }
}
