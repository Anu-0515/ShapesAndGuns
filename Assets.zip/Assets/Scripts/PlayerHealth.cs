using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public float Health;
    public float maxHealth;
    public GameObject DeathScreen;
    public Slider slider;

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy Bullet")
        {
            Health--;
        }
        else if (collision.gameObject.tag == "Heart")
        {
            if (Health < maxHealth)
            {
                Health++;
            }
            Destroy(collision.gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        slider.maxValue = Health;
        maxHealth = Health;
    }

    // Update is called once per frame
    void Update()
    {
        slider.value = Health;
        if(Health <= 0)
        {
            DeathScreen.SetActive(true);
            //Time.timeScale = 0f;
            Destroy(gameObject);
        }
    }

    void AddHealth()
    {
        Health++;
    }
}
