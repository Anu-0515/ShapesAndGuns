﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartGenOne : MonoBehaviour
{
    public GameObject SpawnPos;
    public GameObject Gen2;
    public GameObject Corridor;
    public GameObject EmpCorr;
    public GameObject Wall;
    public LayerMask Itself;
    public GameObject WallPos;

    // Start is called before the first frame update
    void Start()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.TransformDirection(Vector2.up), 40f, ~Itself);
        if (hit)
        {

            Instantiate(Wall, WallPos.transform.position, SpawnPos.transform.rotation);
            Debug.Log(hit.collider.gameObject.name);

        }
        else if (hit.transform == null)
        {
            Instantiate(Corridor, SpawnPos.transform.position, SpawnPos.transform.rotation);

        }
        else if (hit && hit.transform.tag == "Rooms")
        {
            Instantiate(EmpCorr, SpawnPos.transform.position, SpawnPos.transform.rotation);
        }
        StartCoroutine(TimeDelay());
        
    }

    IEnumerator TimeDelay()
    {
        yield return new WaitForSeconds(1);
        Gen2.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
