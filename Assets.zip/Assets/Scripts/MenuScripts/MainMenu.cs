using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public Animator transition;

    public bool IsPaused = false;
    public GameObject PauseUI;
    public GameObject Global_Data;

    void Start()
    {
        Global_Data = GameObject.FindGameObjectWithTag("GlobalData");
    }

    public void PlayGame()
    {
        StartCoroutine(TempTransition(4));
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    public void ExitOptions()
    {
        if (Time.timeScale == 0f)
        {
            Time.timeScale = 1f;
        }
        StartCoroutine(TempTransition(0));
    }

    public void Options()
    {
        StartCoroutine(TempTransition(2));
    }

    public void Pause()
    {
        PauseUI.SetActive(true);
        Time.timeScale = 0f;
    }

    public void Resume()
    {
        PauseUI.SetActive(false);
        Time.timeScale = 1f;
    }

    public void HelpScreen()
    {
        StartCoroutine(TempTransition(3));
    }

    public void CharSelect()
    {
       
    }


    IEnumerator TempTransition(int levelIndex)
    {
        transition.SetTrigger("Start");
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene(levelIndex);
    }

    public void Select_Quad()
    {
        Global_Data.GetComponent<Global_Data>().choice = 1;
        StartCoroutine(TempTransition(1));
    }

    public void Select_Tri()
    {
        Global_Data.GetComponent<Global_Data>().choice = 2;
        StartCoroutine(TempTransition(1));
    }

    public void Select_Cres()
    {
        Global_Data.GetComponent<Global_Data>().choice = 3;
        StartCoroutine(TempTransition(1));
    }
}
