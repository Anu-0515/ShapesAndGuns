﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomGen : MonoBehaviour
{
    //Really long list of rooms
    public GameObject CorrEnd;
    public GameObject L_in_T_out;
    public GameObject R_in_T_out;
    public GameObject L_in_B_out;
    public GameObject R_in_B_out;
    public GameObject B_in_T_out;
    public GameObject T_in_B_out;
    public GameObject T_in_R_out;
    public GameObject T_in_L_out;
    public GameObject B_in_L_out;
    public GameObject B_in_R_out;
    public GameObject L_in_R_out;
    public GameObject R_in_L_out;
    public GameObject DeadEnd;

    public CheckForComplete Check;

    public float randLeft;
    public float randRight;
    public float randTop;
    public float randBottom;
    public int Rrot;
    public int Rint;
    public Quaternion Roomrot;

    public string CorrDir;

    // Start is called before the first frame update
    void OnTriggerEnter2D(Collider2D PosDir)
    {
        CorrDir = PosDir.gameObject.tag;    
    }

    void Start()
    {
        
        Invoke("MainSpw", 0.1f);
        Check = FindObjectOfType(typeof(CheckForComplete)) as CheckForComplete;

    }
    //Main spawning code
    void MainSpw()
    {
        //Variations of Right entry rooms
        if(CorrDir == "RightOpen")
        {
            randRight = Random.Range(1, 7);
            if(randRight == 1)
            {
                GameObject gb = Instantiate(R_in_T_out, CorrEnd.transform.position, R_in_T_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if(randRight == 2)
            {
                GameObject gb = Instantiate(R_in_B_out, CorrEnd.transform.position, R_in_B_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if (randRight == 3 || randRight == 5 || randRight == 6)
            {
                GameObject gb = Instantiate(DeadEnd, CorrEnd.transform.position, CorrEnd.transform.rotation * Quaternion.Euler(0f, 0f, 180f));
                Check.AddRoom(gb);
            }
            else if (randRight == 4)
            {
                GameObject gb = Instantiate(R_in_L_out, CorrEnd.transform.position, R_in_L_out.transform.rotation);
                Check.AddRoom(gb);
            }

        }
        //Variations of Left entry rooms
        if (CorrDir == "LeftOpen")
        {
            randLeft = Random.Range(1, 7);
            if (randLeft == 1)
            {
                GameObject gb = Instantiate(L_in_T_out, CorrEnd.transform.position, L_in_T_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if (randLeft == 2)
            {
                GameObject gb = Instantiate(L_in_B_out, CorrEnd.transform.position, L_in_B_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if (randLeft == 3 || randLeft == 5 || randLeft == 6)
            {
                GameObject gb = Instantiate(DeadEnd, CorrEnd.transform.position, CorrEnd.transform.rotation * Quaternion.Euler(0f, 0f, 180f));
                Check.AddRoom(gb);
            }
            else if(randLeft == 4)
            {
                GameObject gb = Instantiate(L_in_R_out, CorrEnd.transform.position, L_in_R_out.transform.rotation);
                Check.AddRoom(gb);
            }

        }
        //Variations of Top entry rooms
        if (CorrDir == "TopOpen")
        {
            randTop = Random.Range(1, 7);
            if (randTop == 1)
            {
                GameObject gb = Instantiate(T_in_B_out, CorrEnd.transform.position, T_in_B_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if (randTop == 2 || randTop == 5 || randTop == 6)
            {
                GameObject gb = Instantiate(DeadEnd, CorrEnd.transform.position, CorrEnd.transform.rotation * Quaternion.Euler(0f, 0f, 180f));
                Check.AddRoom(gb);
            }
            else if(randTop == 3)
            {
                GameObject gb = Instantiate(T_in_R_out, CorrEnd.transform.position, T_in_R_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if(randTop == 4)
            {
                GameObject gb = Instantiate(T_in_L_out, CorrEnd.transform.position, T_in_L_out.transform.rotation);
                Check.AddRoom(gb);
            }

        }
        //Variations of Bottom entry rooms
        if (CorrDir == "BottomOpen")
        {
            randBottom = Random.Range(1, 7);
            if (randBottom == 1)
            {
                GameObject gb = Instantiate(B_in_T_out, CorrEnd.transform.position, B_in_T_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if (randBottom == 2 || randBottom == 5 || randBottom == 6)
            {
                GameObject gb = Instantiate(DeadEnd, CorrEnd.transform.position, CorrEnd.transform.rotation * Quaternion.Euler(0f, 0f, 180f));
                Check.AddRoom(gb);
            }
            else if(randBottom == 3)
            {
                GameObject gb = Instantiate(B_in_R_out, CorrEnd.transform.position, B_in_R_out.transform.rotation);
                Check.AddRoom(gb);
            }
            else if(randBottom == 4)
            {
                GameObject gb = Instantiate(B_in_L_out, CorrEnd.transform.position, B_in_L_out.transform.rotation);
                Check.AddRoom(gb);
            }

        }
    }





    // Update is called once per frame
    void Update()
    {
        
    }
}
