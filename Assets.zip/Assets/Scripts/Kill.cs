﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kill : MonoBehaviour
{
    public AudioSource For_Enemy;
    public AudioClip enemy_death;

    public float health;
    public float smallforce;
    public int coincount;
    public int heartcount;

    public GameObject BloodSplat;

    public ParticleSystem explodeFX;

    public Renderer rend;
    public Renderer muzzlerend;

    public GameObject muzzle;
    public GameObject coin;
    public GameObject heart;

    private bool IsDead = false;

    //Getting the parts of enemy to disable on death
    void Start()
    {
        coincount = Random.Range(2, 5);
        heartcount = Random.Range(0, 2);
        rend = GetComponent<Renderer>();
        muzzlerend = muzzle.gameObject.GetComponent<Renderer>();
        explodeFX.gameObject.SetActive(false);
    }

    //To take damage
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "bullet")
        {
            health = health - 1f;
        }
    }

    //Death
    void Update()
    {
        if (health <= 0f && IsDead == false)
        {
            IsDead = true;
            Instantiate(BloodSplat, transform.position, transform.rotation);
            for (int i = 0; i < coincount; i++)
            {
                GameObject lootcoin = Instantiate(coin, muzzle.transform.position, muzzle.transform.rotation);
                Rigidbody2D rb = lootcoin.GetComponent<Rigidbody2D>();
                rb.AddForce((muzzle.transform.up + new Vector3(0, 0, Random.Range(-180, 180))) * smallforce, ForceMode2D.Impulse);
            }
            for (int i = 0; i < heartcount; i++)
            {
                GameObject lootheart = Instantiate(heart, muzzle.transform.position, muzzle.transform.rotation);
                Rigidbody2D rb = lootheart.GetComponent<Rigidbody2D>();
                rb.AddForce((muzzle.transform.up + new Vector3(0, 0, Random.Range(-180, 180))) * smallforce, ForceMode2D.Impulse);
            }
            StartCoroutine(Explode());
        }
        /*if(health <= 0f)
        {
            Instantiate(BloodSplat, transform.position, transform.rotation);
            for (int i = 0; i < coincount; i++)
            {
                GameObject lootcoin = Instantiate(coin, muzzle.transform.position, muzzle.transform.rotation);
                Rigidbody2D rb = lootcoin.GetComponent<Rigidbody2D>();
                rb.AddForce((muzzle.transform.up + new Vector3(0, 0, Random.Range(-180, 180))) * smallforce, ForceMode2D.Impulse);
            }
            StartCoroutine(Explode());
        }*/
    }

    IEnumerator Explode()
    {
        this.GetComponent<EnemyAI>().enabled = false;
        this.GetComponent<Collider2D>().enabled = false;
        rend.enabled = false;
        muzzlerend.enabled = false;
        
        explodeFX.gameObject.SetActive(true);
        
        
        yield return new WaitForSeconds(1);
        Destroy(gameObject);
    }

}
