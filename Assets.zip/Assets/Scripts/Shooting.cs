﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shooting : MonoBehaviour
{
    public GameObject player;
    public ParticleSystem FlameFX;
    public AudioSource audioSource_shotgun;
    public AudioClip shotgun_sound;
    public AudioSource audioSource_pistol_select;
    public AudioClip pistol_reload;

    //Positions for projectiles
    public Transform shootfrom;
    public Transform pistol_pos;
    public Transform shotgun_pos;
    public Transform grenade_pos;
    public Transform flthr_pos;

    //Prefabs
    public GameObject pistol;
    public GameObject shotgun;
    public GameObject grenade;
    public GameObject pistol_bullet;
    public GameObject shotgun_bullet;
    public GameObject grenade_projectile;
    public GameObject flamethrower;

    //Fire speeds
    public float pistol_firerate;
    public float shotgun_firerate;
    public float grenade_firerate;

    //Damage values
    public float pistol_dmg;
    public float shotgun_dmg;
    public float grenade_dmg;

    //For Shotgun
    public int no_of_pellets;

    //FOR GRENADE
    public float grenade_aoe;
    public float grenade_force;
    public float explosion_delay;

    //offsets
    public Vector3 pistol_offset;
    public Vector3 shotgun_offset;
    public Vector3 grenade_offset;

    //cooldown values
    public float pistol_cooldown;
    public float shotgun_cooldown;
    public float grenade_cooldown;

    //timers for cooldowm
    private float pistoltimer;
    private float shotguntimer;
    private float grenadetimer;

    public Transform Gun;
    public GameObject BulletPre;
    public float bulletForce = 20f;

    private int weapon_num = 1;
    private GameObject currentgun;

    private bool CanSwitch = true;

    public Joystick shootJoystick;

    public bool canshoot = true;
    public bool buttonpress;

    // Update is called once per frame
    public void AllowShoot()
    {
        buttonpress = true;
    }

    void Update()
    {
        pistoltimer += Time.deltaTime;
        shotguntimer += Time.deltaTime;
        grenadetimer += Time.deltaTime;
        //Debug.Log(Time.time);

        //Weapon switching code
        if ((Input.GetAxis("Mouse ScrollWheel") > 0f && CanSwitch == true) || buttonpress)
        {
            if (weapon_num < 4)
            {
                weapon_num++;
            }
            else if (weapon_num >= 4)
            {
                weapon_num = 1;
            }
            Debug.Log(weapon_num);
            buttonpress = false;
        }
        else if (Input.GetAxis("Mouse ScrollWheel") < 0f && CanSwitch == true)
        {
            if (weapon_num > 1)
            {
                weapon_num--;
            }
            else if (weapon_num <= 1)
            {
                weapon_num = 4;
            }
            Debug.Log(weapon_num);
        }
        if (weapon_num == 1)
        {
            SetGun("Pistol");
            shootfrom = currentgun.transform.GetChild(0);
        }
        if (weapon_num == 2)
        {
            SetGun("Shotgun");
            shootfrom = currentgun.transform.GetChild(0);
        }
        if (weapon_num == 3)
        {
            SetGun("Grenade");
            shootfrom = currentgun.transform.GetChild(0);
        }
        if (weapon_num == 4)
        {
            SetGun("Flamethrower");
            //shootfrom = currentgun.transform.GetChild(0);
        }


        if (shootJoystick.shoot == true)
        {
            canshoot = true;
        }
        else
        {
            canshoot = false;
            FlameFX.gameObject.SetActive(false);
        }

        //Shooting code
        if (Input.GetButton("Fire1") && weapon_num == 1 && pistoltimer >= pistol_cooldown && canshoot)
        {
            pistoltimer = 0f;
            PistolShoot();
            CanSwitch = true;
            //pistol.transform.GetChild(0).gameObject.SetActive(false);
        }
            
        else if (Input.GetButton("Fire1") && weapon_num == 2 && shotguntimer >= shotgun_cooldown && canshoot)
        {
            
            shotguntimer = 0f;
            no_of_pellets = Random.Range(7, 14);
            ShotgunShoot();
            CanSwitch = true;
        }

        else if (Input.GetButton("Fire1") && weapon_num == 3 && grenadetimer >= grenade_cooldown && canshoot)
        {
            grenadetimer = 0f;
            ThrowGrenade();
            CanSwitch = true;
        }

        else if (Input.GetButton("Fire1") && weapon_num == 4 && canshoot)
        {
            FlamethrowerBurn();
            CanSwitch = true;
        }
            /*if (weapon_num == 3)
            {
                SetGun("Grenade");
                shootfrom = currentgun.transform.GetChild(0);
            }*/
        

    }

    void PistolShoot()
    {
        //pistol.transform.GetChild(0).gameObject.SetActive(true);
        CanSwitch = false;
        GameObject bullet = Instantiate(BulletPre, shootfrom.transform.position, player.transform.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(shootfrom.transform.up * 55f, ForceMode2D.Impulse);
    }

    void ShotgunShoot()
    {
        audioSource_shotgun.PlayOneShot(shotgun_sound, 1);
        CanSwitch = false;
        for(int i = 1; i<no_of_pellets; i++)
        {
            GameObject bullet = Instantiate(shotgun_bullet, shootfrom.transform.position, player.transform.rotation * Quaternion.Euler(0,0,Random.Range(-35,35)));
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
            rb.AddForce(bullet.transform.up * 45f, ForceMode2D.Impulse);
        }
    }

    void SetGun(string Gun)
    {
        if(currentgun != null)
        {
            Destroy(currentgun);
        }
        switch (Gun)
        {
            case "Pistol":
                currentgun = Instantiate(pistol, pistol_pos.transform.position, pistol_pos.rotation * Quaternion.Euler(0,0,-90));
                currentgun.transform.SetParent(player.transform);
                break;
            case "Shotgun":
                currentgun = Instantiate(shotgun, shotgun_pos.transform.position, shotgun_pos.rotation * Quaternion.Euler(0, 0, -90));
                currentgun.transform.SetParent(player.transform);
                break;
            case "Grenade":
                currentgun = Instantiate(grenade, grenade_pos.transform.position, grenade_pos.rotation * Quaternion.Euler(0, 0, 0));
                currentgun.transform.SetParent(player.transform);
                break;
            case "Flamethrower":
                currentgun = Instantiate(flamethrower, flthr_pos.transform.position, flthr_pos.rotation * Quaternion.Euler(0, 0, -90));
                currentgun.transform.SetParent(player.transform);
                break;

        }
    }

    void ThrowGrenade()
    {
        CanSwitch = false;
        GameObject grenade = Instantiate(grenade_projectile, shootfrom.transform.position, player.transform.rotation);
        Rigidbody2D rb = grenade.GetComponent<Rigidbody2D>();
        rb.AddForce(grenade.transform.up * bulletForce, ForceMode2D.Impulse);
    }

    void FlamethrowerBurn()
    {
        CanSwitch = false;
        FlameFX.gameObject.SetActive(true);
        
    }

}
