using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explode_Grenade : MonoBehaviour
{
    public AudioSource For_Grenade;
    public AudioClip explosion;

    public float grenade_lifetime;
    public float explosion_force;
    public float radius;

    public ParticleSystem grenadeFX;
    public ParticleSystem smokeFX;

    private Vector3 force_dir;

    void Start()
    {
        For_Grenade = GameObject.FindGameObjectWithTag("GrenadeFX").GetComponent<AudioSource>();
        StartCoroutine(Explode());
        Debug.Log("pls");
        grenadeFX.gameObject.SetActive(false);
        smokeFX.gameObject.SetActive(false);
    }

    IEnumerator Explode()
    {
        yield return new WaitForSeconds(grenade_lifetime);
        For_Grenade.PlayOneShot(explosion, 1);
        grenadeFX.gameObject.SetActive(true);
        smokeFX.gameObject.SetActive(true);
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, 5f);
        foreach (var collider in colliders)
        {
            Debug.Log("I");
            Rigidbody2D rb = collider.GetComponent<Rigidbody2D>();
            if (rb != null && collider.gameObject.tag == "Enemy")
            {
                force_dir = (collider.transform.position - transform.position).normalized;
                rb.AddForce(force_dir * explosion_force, ForceMode2D.Impulse);
                collider.GetComponent<Kill>().health -= 3;
            }
            
        }
        this.GetComponent<SpriteRenderer>().enabled = false;
        yield return new WaitForSeconds(0.6f);
        Destroy(gameObject);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
