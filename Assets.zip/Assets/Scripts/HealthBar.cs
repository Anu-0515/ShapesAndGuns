﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBar : MonoBehaviour
{
    Vector3 localScale;
    public GameObject Parent;
    public float Health;
    // Start is called before the first frame update
    void Start()
    {
        localScale = transform.localScale;

        
    }

    // Update is called once per frame
    void Update()
    {
        Kill kill = Parent.GetComponent<Kill>();
        Health = kill.health;
        localScale.x = Health;
        transform.localScale = localScale;
    }
}
