using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndFight : MonoBehaviour
{
    public GameObject RoomWall;
    public GameObject RoomWall2;
    public GameObject Cross;
    public bool IsRoomClear = false;


    void OnTriggerStay2D(Collider2D other)
    {
        if (other.tag == "Player" && !IsRoomClear)
        {
            StartCoroutine(Finish());
        }
    }

    IEnumerator Finish()
    {
        yield return new WaitForSeconds(2f);
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        if (enemies.Length == 0)
        {
            Cross.SetActive(true);
            IsRoomClear = true;
            Destroy(RoomWall);
            if (RoomWall2 != null)
            {
                Destroy(RoomWall2);
            }
        }

    }
}
