using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_Simple : MonoBehaviour
{
    public Transform turret_target;
    private Vector3 turret_lookDir;
    private float angle;
    public GameObject turret_bullet;
    public Transform muzzle;
    public float bulletForce = 20f;
    public float cooldown = 1f;
    public int deviation;

    private int randomness;
    // Start is called before the first frame update
    void Start()
    {
        turret_target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        randomness = Random.Range(-deviation, deviation);
        turret_lookDir = turret_target.position - transform.position;
        angle = Mathf.Atan2(turret_lookDir.y, turret_lookDir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle) + new Vector3(0, 0, randomness));

        if (Time.time > cooldown)
        {
            GameObject mybullet = Instantiate(turret_bullet, muzzle.position, transform.rotation);
            Rigidbody2D rb = mybullet.GetComponent<Rigidbody2D>();
            rb.AddForce(muzzle.right * bulletForce, ForceMode2D.Impulse);
            cooldown = Time.time + 0.3f;
        }
    }
}
