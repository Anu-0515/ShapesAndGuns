using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetPlayer : MonoBehaviour
{
    public GameObject Global_Data;

    public GameObject Player_Quad;
    public GameObject Player_Tri;
    public GameObject Player_Cres;

    // Start is called before the first frame update
    void Start()
    {
        Global_Data = GameObject.FindGameObjectWithTag("GlobalData");
        if(Global_Data.GetComponent<Global_Data>().choice == 1)
        {
            Player_Quad.SetActive(true);
        }
        else if (Global_Data.GetComponent<Global_Data>().choice == 2)
        {
            Player_Tri.SetActive(true);
        }
        else if (Global_Data.GetComponent<Global_Data>().choice == 3)
        {
            Player_Cres.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
