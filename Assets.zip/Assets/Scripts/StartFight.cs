﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartFight : MonoBehaviour
{
    public GameObject RoomWall;
    public GameObject RoomWall2;
    public GameObject Enemy1;
    public GameObject Enemy2;
    public GameObject Enemy3;
    public GameObject Enemy4;
    public GameObject Enemy5;
    public Collider2D Trigger;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Player")
        {
            RoomWall.SetActive(true);
            if(RoomWall2 != null)
            {
                RoomWall2.SetActive(true);
            }
            StartCoroutine(Fight());

        }

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Enemy1 == null && Enemy2 == null && Enemy3 == null && Enemy4 == null && Enemy5 == null)
        {
            StartCoroutine(EndFight());
        }
    }

    IEnumerator Fight()
    {
        Enemy1.SetActive(true);
        yield return new WaitForSeconds(1);
        Enemy2.SetActive(true);
        yield return new WaitForSeconds(1);
        Enemy3.SetActive(true);
        yield return new WaitForSeconds(1);
        Enemy4.SetActive(true);
        yield return new WaitForSeconds(1);
        Enemy5.SetActive(true);
    }

    IEnumerator EndFight()
    {
        yield return new WaitForSeconds(0.01f);
        Destroy(RoomWall);
        if (RoomWall2 != null)
        {
            Destroy(RoomWall2);
        }
        Destroy(this.gameObject);
    }
}
